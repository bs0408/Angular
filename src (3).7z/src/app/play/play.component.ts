import { Component, OnInit } from '@angular/core';
import { StoringService } from '../storing.service';
import { Stores } from '../Stores';
@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  store : Stores[];
  
  isUpdate  : boolean = false;
  gameid: number;
  gamename : string;
  gamePrice : number;
 

  constructor(private service : StoringService) { }

  ngOnInit() {
  }
  
played(game)
{
  this.service.played(game);
  
}
delete(index)
{
  this.service.delete(index);

}
}